//=============================================================================
// Manjyu_windows.js
//=============================================================================
/*:ja
  * @target MZ
  */
(() => {



//バトルログ背景ラインの透明度
Window_BattleLog.prototype.backPaintOpacity = function() {
    return 128;
};

//戦闘シーン　タイムゲージ位置
Window_StatusBase.prototype.placeTimeGauge = function(actor, x, y) {
    if (BattleManager.isTpb()) {
        this.placeGauge(actor, "time", x + 5, y - 124);
    }
};

//HPMPTPゲージ位置　ゲージの間隔
Window_StatusBase.prototype.placeBasicGauges = function(actor, x, y) {
    this.placeGauge(actor, "hp", x + 2, y);
    this.placeGauge(actor, "mp", x + 2, y + this.gaugeLineHeight());
    if ($dataSystem.optDisplayTp) {
        this.placeGauge(actor, "tp", x + 2, y + this.gaugeLineHeight() * 2);
    }
};

Window_StatusBase.prototype.gaugeLineHeight = function() {
    return 24;
};


//ステータス画面用画像をfaceフォルダからロード
Window_StatusBase.prototype.loadFaceImages = function() {
    for (const actor of $gameParty.members()) {
        ImageManager.loadFace(actor.faceName());
        ImageManager.loadFace(actor.faceName()+ "_" + actor.faceIndex()+ "_st");
    }
};

//アクターフェイス画像表示
Window_StatusBase.prototype.drawActorFace = function(
    actor, x, y, width, height
) {
    this.drawFace(actor.faceName(), actor.faceIndex(), x, y, width, height);
};

//ステータス画面キャラクタープロフィール画像表示
Window_StatusBase.prototype.drawFace3 = function(
    faceName, faceIndex, x, y, width, height
) {
    width = width || ImageManager.faceWidth;
    height = height || ImageManager.faceHeight;
    const bitmap = ImageManager.loadFace(faceName);
    const pw = ImageManager.faceWidth;
    const ph = ImageManager.faceHeight;
    const sw = Math.min(width, pw);
    const sh = Math.min(height, ph);
    const dx = Math.floor(x + Math.max(width - pw, 0) / 2);
    const dy = Math.floor(y + Math.max(height - ph, 0) / 2);
    const sx = (faceIndex % 4) * pw + (pw - sw) / 2;
    const sy = Math.floor(faceIndex / 4) * ph + (ph - sh) / 2;
    this.contents.blt(bitmap, sx, sy, sw + 842, sh + 504, dx - 12, dy + 48);
};

Window_StatusBase.prototype.drawActorFace3 = function(
    actor, x, y, width, height
) {
    this.drawFace3(actor.faceName()+ "_" + actor.faceIndex()+ "_st", 0, x, y - 40, width, height);
};

//ステータス画面から名前と職業ニックネームを消去する
Window_Status.prototype.drawBlock1 = function() {
    const y = this.block1Y();
    this.drawActorFace3(this._actor, 12, y);
    this.drawActorLevel(this._actor, 24, y + 18, 168);
    this.drawActorName(this._actor, 224, y + 18, 168);
    this.drawExpInfo2(452, y + 18,);
//    this.drawActorClass(this._actor, 192, y, 168);
//    this.drawActorNickname(this._actor, 432, y, 270);
};

Window_Status.prototype.drawExpInfo2 = function(x, y) {
    const lineHeight = this.lineHeight();
    const expTotal = TextManager.expTotal.format(TextManager.exp);
    const expNext = TextManager.expNext.format(TextManager.level);
    this.changeTextColor(ColorManager.systemColor());
    this.drawText(expTotal, x, y, 256);
    this.drawText(expNext, x + 260, y, 256);
    this.resetTextColor();
    this.drawText(this.expTotalValue(), x - 48, y, 256, "right");
    this.drawText(this.expNextValue(), x + 260, y, 256, "right");
};

//ステータス画面　ブロック2表示
Window_Status.prototype.drawBlock2 = function() {
    const y = this.block2Y();
    //this.drawActorFace(this._actor, 12, y);
    this.drawBasicInfo2(40, y + 112);
};

Window_Status.prototype.drawExpInfo = function(x, y) {
    const lineHeight = this.lineHeight();
    const expTotal = TextManager.expTotal.format(TextManager.exp);
    const expNext = TextManager.expNext.format(TextManager.level);
    this.changeTextColor(ColorManager.systemColor());
    this.drawText(expTotal, x, y + lineHeight, 270);
    this.drawText(expNext, x, y + lineHeight + 40, 270);
    this.resetTextColor();
    this.drawText(this.expTotalValue(), x-48, y + lineHeight, 270, "right");
    this.drawText(this.expNextValue(), x-48, y + lineHeight + 40, 270, "right");
};

//ステータス画面用ベーシックインフォ
Window_Status.prototype.drawBasicInfo2 = function(x, y) {
    const lineHeight = this.lineHeight();
    this.drawActorIcons(this._actor, x + 16, y - 88);
    this.placeBasicGauges(this._actor, x, y + lineHeight * 2);
};


//ステータス表示から名前を消去
Window_BattleStatus.prototype.drawItemStatus = function(index) {
    const actor = this.actor(index);
    const rect = this.itemRectWithPadding(index);
    const nameX = this.nameX(rect);
    const nameY = this.nameY(rect);
    const stateIconX = this.stateIconX(rect);
    const stateIconY = this.stateIconY(rect);
    const basicGaugesX = this.basicGaugesX(rect);
    const basicGaugesY = this.basicGaugesY(rect);
    this.placeTimeGauge(actor, nameX, nameY);
    //this.placeActorName(actor, nameX, nameY);
    this.placeStateIcon(actor, stateIconX - 146, stateIconY + 20);
    this.placeBasicGauges(actor, basicGaugesX, basicGaugesY);
};

Window_BattleStatus.prototype.faceRect = function(index) {
    const rect = this.itemRect(index);
    rect.pad(-1);
    rect.height = 144;
    return rect;
};

//装備画面Face画像表示位置調整
Window_EquipStatus.prototype.refresh = function() {
    this.contents.clear();
    if (this._actor) {
        const nameRect = this.itemLineRect(0);
        this.drawActorName(this._actor, nameRect.x, 0, nameRect.width);
        this.drawActorFace(this._actor, 66, nameRect.height + 8);
        this.drawAllParams();
    }
};

//スキル画面ステータス表示調整
Window_SkillStatus.prototype.refresh = function() {
    Window_StatusBase.prototype.refresh.call(this);
    if (this._actor) {
        const x = this.colSpacing() / 2;
        const h = this.innerHeight;
        const y = h / 2 - this.lineHeight() * 1.5;
        this.drawActorFace(this._actor, x + 1, 0, 160, h);
        this.drawActorSimpleStatus(this._actor, x + 180, y);
    }
};

//戦闘シーン　アクターフェイス画像と背景画像を表示させる
Window_Base.prototype.drawFace2 = function(
    faceName, faceIndex, x, y, width, height
) {
    width = width || ImageManager.faceWidth;
    height = height || ImageManager.faceHeight;
    const bitmap = ImageManager.loadFace(faceName);
    const pw = ImageManager.faceWidth;
    const ph = ImageManager.faceHeight;
    const sw = Math.min(width, pw);
    const sh = Math.min(height, ph) + 16;
    const dx = Math.floor(x + Math.max(width - pw, 0) / 2);
    const dy = Math.floor(y + Math.max(height - ph, 0) / 2);
    const sx = (faceIndex % 4) * pw + (pw - sw) / 2;
    const sy = Math.floor(faceIndex / 4) * ph + (ph - sh) / 2;
    this.contents.blt(bitmap, sx + 1, sy, sw + 48, sh + 80, dx, dy);
};

Window_StatusBase.prototype.drawActorFace2 = function(
    actor, x, y, width, height
) {
    this.drawFace2("Actor_bb", 0 , x - 16, y, width, height);
};

Window_BattleStatus.prototype.drawItemImage = function(index) {
    const actor = this.actor(index);
    const rect = this.faceRect(index);
    this.drawActorFace(actor, rect.x, rect.y + 22, rect.width, rect.height);
    this.drawActorFace2(actor, rect.x, rect.y, rect.width, rect.height);
};

//戦闘シーン　アクターステータスに外枠をつける
Window_BattleStatus.prototype.initialize = function(rect) {
    Window_StatusBase.prototype.initialize.call(this, rect);
    this.frameVisible = true;
    this.openness = 0;
    this._bitmapsReady = 0;
    this.preparePartyRefresh();
};



})();