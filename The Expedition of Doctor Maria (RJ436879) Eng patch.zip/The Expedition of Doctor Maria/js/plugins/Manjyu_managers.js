//=============================================================================
// Manjyu_managers.js
//=============================================================================
/*:ja
  * @target MZ
  */
(() => {

//顔グラフィックのサイズ規定を144*144から変更する
ImageManager.faceWidth = 160;
ImageManager.faceHeight = 160;

//戦闘からの逃走が成功する確率計算を変更する
//(味方全体の素早さ * 0.5 / 敵全体の素早さ）+ 補正
BattleManager.makeEscapeRatio = function() {
    this._escapeRatio = (0.5 * $gameParty.agility()) / $gameTroop.agility() + 0.3;
};
  
})();