//=============================================================================
// Manjyu_objects.js
//=============================================================================
/*:ja
  * @target MZ
  */
(() => {

//クリティカルダメージ計算
Game_Action.prototype.applyCritical = function(damage) {
    return damage * 2;
};

//毒の床ダメージ
Game_Actor.prototype.checkFloorEffect = function() {
    if ($gamePlayer.isOnDamageFloor()) {
        this.executeFloorDamage();
    }
};

Game_Actor.prototype.executeFloorDamage = function() {
    const floorDamage = Math.floor(this.basicFloorDamage() * this.fdr);
    const realDamage = Math.min(floorDamage, this.maxFloorDamage());
    this.gainHp(-realDamage);
    if (realDamage > 0) {
        this.performMapDamage();
    }
};

Game_Actor.prototype.basicFloorDamage = function() {
    if ($gameSwitches.value(1)) {
        return 0;
    } else {
        return $gameVariables.value(4);
    }
};

Game_Actor.prototype.performMapDamage = function() {
    if (!$gameParty.inBattle()) {
    if ($gameSwitches.value(1)) {
 
    } else {
        $gameScreen.startFlashForDamage();
    }
    }
};


})();