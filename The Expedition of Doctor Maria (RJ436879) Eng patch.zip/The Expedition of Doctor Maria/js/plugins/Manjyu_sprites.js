//=============================================================================
// Manjyu_sprites.js
//=============================================================================
/*:ja
  * @target MZ
  */
(() => {



//戦闘シーン背景を拡大させない処理
Sprite_Battleback.prototype.adjustPosition = function() {
    this.width = 1024;
    this.height = 768;
    this.x = 0;
    this.y = 0;

    const ratioX = this.width / this.bitmap.width;
    const ratioY = this.height / this.bitmap.height;
    const scale = Math.max(ratioX, ratioY, 1.0);
    this.scale.x = scale;
    this.scale.y = scale;
};

//戦闘シーンで敵キャラの表示位置を1.6倍解像度に合わせて調整する処理
Sprite_Battler.prototype.setHome = function(x, y) {
    this._homeX = x * 1.25;
    this._homeY = y * 1.25 - 8;
    this.updatePosition();
};

//ゲージの長さ
Sprite_Gauge.prototype.bitmapWidth = function() {
    return 166;
};

//ゲージ左のHPMPTPの文字の大きさ
Sprite_Gauge.prototype.labelFontSize = function() {
    return $gameSystem.mainFontSize() - 6;
};

//ゲージの上に乗っかる数字の大きさ
Sprite_Gauge.prototype.valueFontSize = function() {
    return $gameSystem.mainFontSize() - 6;
};

//HPMPTPの文字縁取りの太さ
Sprite_Gauge.prototype.valueOutlineWidth = function() {
    return 3;
};

//ゲージの位置
Sprite_Gauge.prototype.drawGauge = function() {
    const gaugeX = this.gaugeX();
    const gaugeY = this.bitmapHeight() - this.gaugeHeight() - 8;
    const gaugewidth = this.bitmapWidth() - gaugeX;
    const gaugeHeight = this.gaugeHeight();
    this.drawGaugeRect(gaugeX, gaugeY+2, gaugewidth, gaugeHeight - 4);
};

//ゲージの上に乗っかる数字の位置　最大値も表示するようにしてある
Sprite_Gauge.prototype.drawValue = function() {
    const currentValue = this.currentValue();
    const currentMaxValue = this.currentMaxValue();
    const width = this.bitmapWidth();
    const height = this.bitmapHeight();
    this.setupValueFont();
    this.bitmap.drawText(currentValue, -16, 0, width, height, "center");
    this.bitmap.drawText("/", 16, 0, width, height, "center");
    this.bitmap.drawText(currentMaxValue, 48, 0, width, height, "center");
};



})();